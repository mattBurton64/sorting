# Defect Log

- **Team Name:** Cloud Nine  
- **Team Members:** Jeremy Maas, Matt Burton, McHale Trotter, Kevin Sampson, Justin Chen, Ryan Hirscher

## Bug 1

- **Issue Description:** The docker was constantly restarting and we couldnt log into the database  
- **Date Found:** 2/13/24  
- **Action Plan:** Research the errors found in the docker log
- **Assignee(s):** Matt and Kevin
- **Date Fixed:** 2/14/24  
- **Solution:** Deleted the maradb-data volume and recomposed the docker to recreated the volume

## Bug 2

- **Issue Description:** The schema file tried to implement ararys to handle the list of flights which isnt supported by sql
- **Date Found:** 2/9/24
- **Action Plan:** Create a separate table to manage the routes and flights relationships
- **Assignee(s):** Matt, Jeremy, and Ryan
- **Date Fixed:** 2/14/24  
- **Solution:** We created a separate table to manage the connection between flights and routes

## Bug 3

- **Issue Description:** The number of attributes in the populate-aircraft-table.sql didnt match the schema nor did the names of the attributes
- **Date Found:** 2/10/24
- **Action Plan:** Get with Justin and confirm aircraft attributes and ERD attributes
- **Assignee(s):** Matt and Justin
- **Date Fixed:** 2/12/24  
- **Solution:** Ensuring the aircraft attributes matched the ERD and that the ERD was functional

## Bug 4

- **Issue Description:** Pushing the meeting minutes to the documentation branch resulted in a divergent branch issue
- **Date Found:** 2/15/24
- **Action Plan:** Rebase the branch
- **Assignee(s):** Matt
- **Date Fixed:** 2/15/24  
- **Solution:** Ran git rebase

## Bug 5

- **Issue Description:** The sql trigger for the flight angle attribute in the flights table was only populating null values
- **Date Found:** 2/22/24
- **Action Plan:** Add a line to drop the trigger if it already exists, (the old trigger was still in place)
- **Assignee(s):** McHale
- **Date Fixed:** 2/23/24  
- **Solution:** Renamed the trigger from "calculate_flight_angle" to "calculate_flight_angle1" and added a line to drop the trigger if it exists already.

## Bug 6

- **Issue Description:** Adding and removing gates allowed for negative and more than total gate value
- **Date Found:** 3/18/24
- **Action Plan:** Add exception handling for when the program calls to add or remove a gate when it doesnt make sense
- **Assignee(s):** Matt
- **Date Fixed:** 3/18/24  
- **Solution:** Add exception handling for when the program calls to add or remove a gate when it doesnt make sense
