"""
Manage the current simulation time

__team_name__ = Cloud Nine
__team_members__ = Jeremy Maas, Matt Burton, McHale Trotter, Kevin Sampson, Justin Chen, Ryan Hirscher
__author__ = Matt Burton

Notes: Currently, no support for daylight savings time
   This class is not meant to be a stand-alone class, instead
   it will be used by the main simulation

Execute:  
    1. Move to the /comfort-airlines directory
    2. Execute the file using the following command in the terminal:
        python3 clock.py

"""

class Clock:
    def __init__(self):
        self.time = (1, 0, 0)  # (day, hour, minute)

    def reset_clock(self):
        self.time = (1, 0, 0)

    def increment_clock(self):
        day, hour, minute = self.time # temporarily breakdown time into its parts
        
        # Increment the clock by one minute
        minute += 1
        
        # Check to increment the hour
        if minute == 60:
            minute = 0
            hour += 1
            
            # Check to increment the day
            if hour == 24:
                hour = 0
                day += 1
        
        # set the time with the updated value(s)
        self.time = (day, hour, minute)
    
    def print_time(self):
        day, hour, minute = self.time # temporarily breakdown time into its parts

        print("Day:" + str(day) + " " + str(hour) + ":" + str(minute))

clock = Clock() # create a new clock object

# test the incrementing and output for a single day
for i in range(0,1441):
    clock.print_time()
    clock.increment_clock()
