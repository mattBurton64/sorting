/*
 * parser.h
 *
 *  Created on: Nov 9, 2023
 *      Author: Matt Burton
 */

#ifndef PARSER_H_
#define PARSER_H_

#include <iostream>
#include <fstream>
#include <string>

#include "scanner.h"
#include "symbol.h"
#include "token.h"
#include "error_handler.h"

using namespace std;

class parser {
private:
	bool debugging {false};			// Set debugging to true to execute statement to help debug the parser, otherwise set to false.

  error_handler* error;
  scanner* scan;
  
  void prog();     
  void block();     
  void declaration();
  void type();       
  void param_list();  
  void param();        
  void ident_list();    
  void param_kind();     
  void statement_list();  
  void statement();        
  void simple_statement();  
  void compound_statement();
  void if_statement();      
  void while_statement();   
  void for_statement();     
  void loop_statement();    
  void range();             
  void expr();              
  void boolean();           
  void relop();             
  void simple_expr();       
  void stringop();          
  void expr2();           
  void addop();             
  void term();              
  void multop();            
  void factor();            
  void primary();           
  void string();
  void ident();             
  void ident2();            
  void number();  
  void digit_seq();         
  void exp();               
  void pragma();            

public:

  parser(scanner* sc, error_handler* err);
  ~parser();

  void program(); // Starts parsing the program
};
#endif /* PARSER_H_ */
