/*
 * parser.cpp
 *
 *  Created on: Nov 9, 2023
 *      Author: Matt Burton
 */

#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <cctype>
#include <cmath>
#include <vector>

#include "symbol.h"
#include "error_handler.h"
#include "token.h"
#include "scanner.h"
#include "lille_exception.h"
#include "parser.h"
#include "lille_type.h"

using namespace std;

parser::parser(scanner* scan, error_handler* err, id_table* table)
{
  this->scan = scan;
  this->error = err;
  this->id_tab = table;
}

void parser::prog() // <prog> ::= program <ident> is <block> ;
{
  if (debugging)
    cout << "Parser: entering prog" << endl;
  
  id_table_entry* program_entry;

  scan->must_be(symbol::program_sym);
  std::string prog_name = scan->this_token()->get_identifier_value();
  // add the program name to the id table at scope level 0
  program_entry = id_tab->enter_id(scan->this_token(), lille_type::type_prog, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
  ident();
  
  //id_tab->enter_scope();

  scan->must_be(symbol::is_sym);
  block(prog_name, true);
  scan->must_be(symbol::semicolon_sym);

  //id_tab->exit_scope();

  if (debugging)
    cout << "Parser: exiting prog" << endl;
}

// <block> ::= { <declaration> }* begin <statement_list> end [ <ident> ]
void parser::block(std::string block_name, bool prog_ident)
{
  if (debugging)
    cout << "Parser: entering block" << endl;

  while (scan->have(symbol::identifier) or scan->have(symbol::procedure_sym) or scan->have(symbol::function_sym))
    declaration();
  scan->must_be(symbol::begin_sym);
  statement_list();

  scan->must_be(symbol::end_sym);
  if (scan->have(symbol::identifier))
  {
    if (scan->this_token()->get_identifier_value() != block_name)
    {
      if (prog_ident)
      {
        error->flag(scan->this_token(), 75);
      }
      else
      {
        error->flag(scan->this_token(), 107);
      }
    }
    scan->get_token();
  }

  if (debugging)
    cout << "Parser: exiting block" << endl;
}

// <declaration> ::= <ident_list> : [ constant ] <type>[:=<number> | :=<string> | :=<bool>] ;
//                 | procedure <ident> [ ( <param_list> ) ] is <block> ;
//                 | function <ident> [(<param_list>)] return <type> is <block> ;
void parser::declaration()
{ 
  if (debugging)
    cout << "Parser: entering declaration" << endl;
  
  // variables for semantic analysis
  vector<token*> token_list;
  vector<id_table_entry*> id_list;
  bool comma_found = false;
  bool semicolon_found = false;
  lille_type ty;
  std::string block_name;

  if (scan->have(symbol::identifier))
  {
    // variables for semantic analysis
    bool const_decl = false;
    int i_const;
    float r_const;
    std::string s_const;
    bool b_const;

    //ident_list(); 
    if (scan->have(symbol::identifier)) // collect a list of identifiers
    {
      do {
        if (scan->have(symbol::identifier))
        {
          token_list.push_back(scan->this_token());
          scan->get_token();
        }
        comma_found = false;
        if(scan->have(symbol::comma_sym))
        {
          scan->get_token();
          comma_found = true;
        }
      } while (comma_found);
    }
    scan->must_be(symbol::colon_sym);
    if(scan->have(symbol::constant_sym))
    {
      const_decl = true; // track whether identifiers are constants
      scan->get_token();
    }
    ty = type(); // tracks the type of the identifiers

    for (int i = 0; i < token_list.size(); i++) // add identifiers to the id_table
      id_list.push_back(id_tab->enter_id(token_list[i], ty, const_decl ? lille_kind::constant : lille_kind::variable, id_tab->scope(), 0, lille_type::type_unknown));

    if (scan->have(symbol::becomes_sym))
    {
      scan->get_token();
      if (scan->have(symbol::integer))
      {
        i_const = scan->this_token()->get_integer_value();
        if (!ty.is_type(lille_type::type_integer))
          error->flag(scan->this_token(), 111); // const expression does not match type declaration
        scan->get_token();
      }
      else if (scan->have(symbol::real_num))
      {
        r_const = scan->this_token()->get_real_value();
        if (!ty.is_type(lille_type::type_real))
          error->flag(scan->this_token(), 111); // const expression does not match type declaration
        scan->get_token();
      }
      else if (scan->have(symbol::strng))
      {
        s_const = scan->this_token()->get_string_value();
        if (!ty.is_type(lille_type::type_string))
          error->flag(scan->this_token(), 111); // const expression does not match type declaration
        scan->get_token();
      }
      else if (scan->have(symbol::true_sym))
      {
        b_const = true;
        if (!ty.is_type(lille_type::type_boolean))
          error->flag(scan->this_token(), 111); // const expression does not match type declaration
        scan->get_token();
      }
      else if (scan->have(symbol::false_sym))
      {
        b_const = false;
        if (!ty.is_type(lille_type::type_boolean))
          error->flag(scan->this_token(), 111); // const expression does not match type declaration
        scan->must_be(symbol::boolean_sym);
      }
    } 
    for (int i = 0; i < token_list.size(); i++) // assign the value to the identifiers
      id_list[i]->fix_const(i_const, r_const, s_const, b_const);    
    scan->must_be(symbol::semicolon_sym);
  }
  else if (scan->have(symbol::procedure_sym))
  {
    id_table_entry* proc_id;

    scan->must_be(symbol::procedure_sym);
    // add procedure to the id_table
    proc_id = id_tab->enter_id(scan->this_token(), lille_type::type_proc, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
    block_name = scan->this_token()->get_identifier_value();
    scan->must_be(symbol::identifier);

    //id_tab->enter_scope();

    if (scan->have(symbol::left_paren_sym))
    {
      scan->get_token();
      //param_list();
      do { // handles lists of parameters
        token_list.clear();
        do { // handles lists of identifiers
          if (scan->have(symbol::identifier))
          {
            token_list.push_back(scan->this_token());
            scan->get_token();
          }
          comma_found = false;
          if(scan->have(symbol::comma_sym))
          {
            scan->get_token();
            comma_found = true;
          }
        } while (comma_found);

        scan->must_be(symbol::colon_sym);

        lille_kind param_kind;
        if (scan->have(symbol::ref_sym))
          param_kind = lille_kind::ref_param;
        else if (scan->have(symbol::value_sym))
          param_kind = lille_kind::value_param;
        scan->get_token();

        ty = type();
        
        semicolon_found = false;
        if(scan->have(symbol::semicolon_sym))
        {
          scan->get_token();
          semicolon_found = true;
        }

        for (int i = 0; i < token_list.size(); i++) // add identifiers to the id_table
        {
          id_table_entry* param_id = new id_table_entry(token_list[i], ty, param_kind, id_tab->scope(), 0, lille_type::type_unknown);
          id_tab->add_table_entry(param_id);
          proc_id->add_param(param_id);
        }
      } while (semicolon_found);
      scan->must_be(symbol::right_paren_sym);
    }
    scan->must_be(symbol::is_sym);
    block(block_name, false);
    scan->must_be(symbol::semicolon_sym);

    //id_tab->exit_scope();
  }
  else if (scan->have(symbol::function_sym))
  {
    lille_type return_type;
    id_table_entry* func_id;

    scan->get_token();
    
    //add function entry to the id_table
    func_id = id_tab->enter_id(scan->this_token(), lille_type::type_func, lille_kind::unknown, id_tab->scope(), 0, lille_type::type_unknown);
    block_name = scan->this_token()->get_identifier_value();
    scan->must_be(symbol::identifier);

    //id_tab->enter_scope();

    if (scan->have(symbol::left_paren_sym))
    {
      scan->must_be(symbol::left_paren_sym);
      //param_list();      
      do { // handles lists of parameters
        token_list.clear();
        do { // handles lists of identifiers
          if (scan->have(symbol::identifier))
          {
            token_list.push_back(scan->this_token());
            scan->get_token();
          }
          comma_found = false;
          if(scan->have(symbol::comma_sym))
          {
            scan->get_token();
            comma_found = true;
          }
        } while (comma_found);

        scan->must_be(symbol::colon_sym);

        lille_kind param_kind;
        if (scan->have(symbol::ref_sym))
          param_kind = lille_kind::ref_param;
        else if (scan->have(symbol::value_sym))
          param_kind = lille_kind::value_param;
        scan->get_token();

        ty = type();
        
        semicolon_found = false;
        if(scan->have(symbol::semicolon_sym))
        {
          scan->get_token();
          semicolon_found = true;
        }

        for (int i = 0; i < token_list.size(); i++) // add identifiers to the id_table
        {
          id_table_entry* param_id = new id_table_entry(token_list[i], ty, param_kind, id_tab->scope(), 0, lille_type::type_unknown);
          id_tab->add_table_entry(param_id);
          func_id->add_param(param_id);
        }  
      } while (semicolon_found);
      
      scan->must_be(symbol::right_paren_sym);
    }
    scan->must_be(symbol::return_sym);
    return_type = type();
    func_id->fix_return_type(return_type);
    scan->must_be(symbol::is_sym);
    block(block_name, false);
    scan->must_be(symbol::semicolon_sym);

    //id_tab->exit_scope();
  }

  if (debugging)
    cout << "Parser: exiting declaration" << endl;
}

// <type> ::= integer 
//          | real 
//          | string 
//          | boolean
lille_type parser::type() 
{
  if (debugging)
    cout << "Parser: entering type" << endl;

  lille_type return_type;

  if (scan->have(symbol::integer_sym))
  {
    return_type = lille_type::type_integer;
    scan->get_token();
  }
  else if (scan->have(symbol::real_sym))
  {
    return_type = lille_type::type_real;
    scan->get_token();
  }  
  else if (scan->have(symbol::string_sym))
  {
    return_type = lille_type::type_string;
    scan->get_token();
  }
  else 
  {
    return_type = lille_type::type_integer;
    scan->must_be(symbol::boolean_sym);
  }

  if (debugging)
    cout << "Parser: exiting type" << endl;

  return return_type;
}

// <param_list> ::= <param> { ; <param> }*
void parser::param_list()
{
  if (debugging)
    cout << "Parser: entering param_list" << endl;
  
  param();

  while(scan->have(symbol::semicolon_sym))
  {
    scan->must_be(symbol::semicolon_sym);
    param();
  }

  if (debugging)
    cout << "Parser: exiting param_list" << endl;
}

// <param> ::= <ident_list> : <param_kind> <type>
void parser::param()
{
  if (debugging)
    cout << "Parser: entering param" << endl;

  ident_list();
  scan->must_be(symbol::colon_sym);
  param_kind();
  type();

  if (debugging)
    cout << "Parser: exiting param" << endl;
}

// <ident_list> ::= <ident> { , <ident> }*
void parser::ident_list()
{
  if (debugging)
    cout << "Parser: entering ident_list" << endl;

  ident();
  while(scan->have(symbol::comma_sym))
  {
    scan->get_token();
    ident();
  }

  if (debugging)
    cout << "Parser: exiting ident_list" << endl;
}

// <param_kind> ::= value 
//                | ref
void parser::param_kind()
{
  if (debugging)
    cout << "Parser: entering param_kind" << endl;

  if (scan->have(symbol::value_sym))
    scan->get_token();
  else
    scan->must_be(symbol::ref_sym);

  if (debugging)
    cout << "Parser: exiting param_kind" << endl;
}

// <statement_list> ::= <statement> ; { <statement> ; }*
void parser::statement_list()
{
  if (debugging)
    cout << "Parser: entering statement_list" << endl;

  statement();
  scan->must_be(symbol::semicolon_sym);
  while(scan->have(symbol::identifier) or scan->have(symbol::exit_sym) or scan->have(symbol::return_sym) or scan->have(symbol::read_sym) or scan->have(symbol::write_sym) or scan->have(symbol::writeln_sym) or scan->have(symbol::null_sym) or scan->have(symbol::if_sym) or scan->have(symbol::while_sym) or scan->have(symbol::for_sym) or scan->have(symbol::loop_sym))
  {
    statement();
    scan->must_be(symbol::semicolon_sym);
  }

  if (debugging)
    cout << "Parser: exiting statement_list" << endl;
}

// <statement> ::= <simple_statement>
//               | <compound_statemen
void parser::statement()
{
  if (debugging)
    cout << "Parser: entering statement" << endl;

  if (scan->have(symbol::identifier) or scan->have(symbol::exit_sym) or scan->have(symbol::return_sym) or scan->have(symbol::read_sym) or scan->have(symbol::write_sym) or scan->have(symbol::writeln_sym) or scan->have(symbol::null_sym))
    simple_statement();
  else if (scan->have(symbol::if_sym) or scan->have(symbol::while_sym) or scan->have(symbol::for_sym) or scan->have(symbol::loop_sym))
    compound_statement();
  else
    error->flag(scan->this_token(), 80); // statement expected

  if (debugging)
    cout << "Parser: exiting statement" << endl;
}

// <simple_statement> ::= <ident> [ ( <expr> { , <expr> }* ) ]
//                      | <ident> := <expr>
//                      | exit [ when <expr> ]
//                      | return [ <expr> ]
//                      | read [ ( ] <ident> { , <ident> }* [ ) ]
//                      | write [ ( ] <expr> { , <expr> }* [ ) ]
//                      | writeln [ ( ] [ <expr> { , <expr> }* ] [ ) ]
//                      | null
void parser::simple_statement()
{
  if (debugging)
    cout << "Parser: entering simple_statement" << endl;

  bool open_paren = false; // tracks if there is an open parentheses, requires closing paren

  if (scan->have(symbol::identifier))
  {
    token* tok = scan->this_token(); // function or procedure name
    id_table_entry* id_info = id_tab->lookup(tok); 
    ident();
    if (scan->have(symbol::left_paren_sym))
    {    
      if (!id_info->tipe().is_type(lille_type::type_proc))
        error->flag(tok, 90); // identifier must be a procedure name in this context
      scan->get_token();

      int param_count = 1;
      expr();
      while(scan->have(symbol::comma_sym))
      {
        scan->get_token();
        expr();
        param_count++;
      }

      if (param_count != id_info->number_of_params())
        error->flag(scan->this_token(), 97); // mismatched amount of formal and actual parameters

      scan->must_be(symbol::right_paren_sym);
    }
    else if (scan->have(symbol::becomes_sym))
    {
      scan->get_token();
      if (!(id_info->kind().is_kind(lille_kind::variable) or (id_info->kind().is_kind(lille_kind::ref_param))))
        error->flag(tok, 85); // identifier is not assignable, must be a variable or reference parameter

      if (scan->have(symbol::not_sym) or scan->have(symbol::odd_sym) or scan->have(symbol::left_paren_sym) or scan->have(symbol::identifier) or scan->have(symbol::integer) or scan->have(symbol::real_num) or scan->have(symbol::strng) or scan->have(symbol::true_sym) or scan->have(symbol::false_sym) or scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym))
      {
        lille_type expr_type = expr();
        if (!id_info->tipe().is_equal(expr_type))
          error->flag(scan->this_token(), 93); // LHS and RHS are assignment are not compatible
      }
      else
        error->flag(tok, 91); // Identifier illegal in this context

      /*if (!(id_info->kind().is_kind(lille_kind::variable) or (id_info->kind().is_kind(lille_kind::ref_param))))
      {
        //trace_write(id_info, true);
        cout << "trace write" << endl;
      }  
      else
        error->flag(scan->this_token(), 92); // String or expression expected*/
    }
  }
  else if (scan->have(symbol::exit_sym))
  {
    scan->get_token();
    if(scan->have(symbol::when_sym))
    {
      scan->get_token();
      expr();
    }
  }
  else if (scan->have(symbol::return_sym))
  {
    scan->get_token();
    if (scan->have(symbol::not_sym) or scan->have(symbol::odd_sym) or scan->have(symbol::left_paren_sym) or scan->have(symbol::identifier) or scan->have(symbol::integer) or scan->have(symbol::real_num) or scan->have(symbol::strng) or scan->have(symbol::true_sym) or scan->have(symbol::false_sym) or scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym))
      expr();
  }
  else if (scan->have(symbol::read_sym))
  {
    scan->get_token();
    if (scan->have(symbol::left_paren_sym))
    {
      scan->get_token();
      open_paren = true;
    }
    ident();
    while(scan->have(symbol::comma_sym))
    {
      scan->get_token();
      ident();
    }
    if (open_paren)
      scan->must_be(symbol::right_paren_sym);
    else if (scan->have(symbol::right_paren_sym))
      error->flag(scan->this_token(), 83); // simple statement expected, unbalanced parentheses
  }
  else if (scan->have(symbol::write_sym))
  {
    scan->get_token();
    if (scan->have(symbol::left_paren_sym))
    {
      scan->get_token();
      open_paren = true;
    }
    expr();
    while(scan->have(symbol::comma_sym))
    {
      scan->get_token();
      expr();
    }
    if (open_paren)
      scan->must_be(symbol::right_paren_sym);  
    else if (scan->have(symbol::right_paren_sym))
      error->flag(scan->this_token(), 83); // simple statement expected, unbalanced parentheses
  }
  else if (scan->have(symbol::writeln_sym))
  {
    scan->get_token();
    if (scan->have(symbol::left_paren_sym))
    {
      scan->get_token();
      open_paren = true;
    }
    if (scan->have(symbol::not_sym) or scan->have(symbol::odd_sym) or scan->have(symbol::left_paren_sym) or scan->have(symbol::identifier) or scan->have(symbol::integer) or scan->have(symbol::real_num) or scan->have(symbol::strng) or scan->have(symbol::true_sym) or scan->have(symbol::false_sym) or scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym))
    {
      expr();
      while(scan->have(symbol::comma_sym))
      {
        scan->get_token();
        expr();
      }
    }
    if (open_paren)
      scan->must_be(symbol::right_paren_sym);  
    else if (scan->have(symbol::right_paren_sym))
      error->flag(scan->this_token(), 83); // simple statement expected, unbalanced parentheses
  }
  else if (scan->have(symbol::null_sym))
    scan->get_token();
  else
    error->flag(scan->this_token(), 83); // simple statement expected

  if (debugging)
    cout << "Parser: exiting simple_statement" << endl;
}

// <compound_statement> ::= <if_statement>
//                        | <loop_statement>
//                        | <for_statement>
//                        | <while_statement
void parser::compound_statement()
{
  if (debugging)
    cout << "Parser: entering compound_statement" << endl;

  if (scan->have(symbol::if_sym))
    if_statement();
  else if (scan->have(symbol::loop_sym))
    loop_statement();
  else if (scan->have(symbol::for_sym))
    for_statement();
  else if (scan->have(symbol::while_sym))
    while_statement();
  else
    error->flag(scan->this_token(), 101); // compound statement expected

  if (debugging)
    cout << "Parser: exiting compound_statement" << endl;
}

// <if_statement> ::= if <expr> then <statement_list> { elsif <expr> then <statement_list> }* [ else <statement_list> ] end if
void parser::if_statement()
{
  if (debugging)
    cout << "Parser: entering if_statement" << endl;

  scan->must_be(symbol::if_sym);
  expr();
  scan->must_be(symbol::then_sym);

  //id_tab->enter_scope();
  statement_list();
  //id_tab->exit_scope();

  while (scan->have(symbol::elsif_sym))
  {
    scan->must_be(symbol::elsif_sym);
    expr();
    scan->must_be(symbol::then_sym);
    
    //id_tab->enter_scope();
    statement_list();
    //id_tab->exit_scope();
  }
  if (scan->have(symbol::else_sym))
  {
    scan->get_token();

    //id_tab->enter_scope();
    statement_list();
    //id_tab->exit_scope();
  }
  scan->must_be(symbol::end_sym);
  scan->must_be(symbol::if_sym);

  if (debugging)
    cout << "Parser: exiting if_statment" << endl;
}

// <while_statement> ::= while <expr> <loop_statement>
void parser::while_statement()
{
  if (debugging)
    cout << "Parser: entering while_statment" << endl;
  
  

  scan->must_be(symbol::while_sym);
  expr();

  //id_tab->enter_scope();
  loop_statement();
  //id_tab->exit_scope();

  if (debugging)
    cout << "Parser: exiting while_statement" << endl;
}

// <for_statement> ::= for <ident> in [ reverse ] <range> <loop_statement>
void parser::for_statement()
{
  if (debugging)
    cout << "Parser: entering for_statement" << endl;

  //id_tab->enter_scope();

  scan->must_be(symbol::for_sym);
  ident();
  scan->must_be(symbol::in_sym);
  if (scan->have(symbol::reverse_sym))
    scan->get_token();
  range();
  loop_statement();

  //id_tab->exit_scope();

  if (debugging)
    cout << "Parser: exiting for_statement" << endl;
}

// <loop_statement> ::= loop <statement_list> end loop
void parser::loop_statement()
{
  if (debugging)
    cout << "Parser: entering loop_statement" << endl;

  scan->must_be(symbol::loop_sym);
  statement_list();
  scan->must_be(symbol::end_sym);
  scan->must_be(symbol::loop_sym);

  if (debugging)
    cout << "Parser: exiting loop_statement" << endl;
}

// <range> ::= <simple_expr> .. <simple_expr>
void parser::range()
{
  if (debugging)
    cout << "Parser: entering range" << endl;

  simple_expr();
  scan->must_be(symbol::range_sym);
  simple_expr();

  if (debugging)
    cout << "Parser: exiting range" << endl;
}

// <expr> ::= <simple_expr> [ <relop> <simple_expr> ]
//          | <simple_expr> in <range>
lille_type parser::expr()
{
  if (debugging)
    cout << "Parser: entering expr" << endl;

  lille_type return_type;

  return_type = simple_expr();

  if (scan->have(symbol::greater_than_sym) or scan->have(symbol::less_than_sym) or scan->have(symbol::equals_sym) or scan->have(symbol::not_equals_sym) or scan->have(symbol::less_or_equal_sym) or scan->have(symbol::greater_or_equal_sym)) 
  {
    relop();
    simple_expr();
  }
  else if (scan->have(symbol::in_sym))
  {
    scan->get_token();
    range();
  }
  
  if (debugging)
    cout << "Parser: exiting expr" << endl;

  return return_type;
}

//<bool> ::= true
//         | false
lille_type parser::boolean()
{
  if (debugging)
    cout << "Parser: entering boolean" << endl;

  if (scan->have(symbol::true_sym))
    scan->get_token();
  else 
    scan->must_be(symbol::false_sym);

  if (debugging)
    cout << "Parser: exiting boolean" << endl;

  return lille_type(lille_type::type_boolean);
}

// <relop> ::= > 
//           | < 
//           | = 
//           | <> 
//           | <= 
//           | >=
void parser::relop()
{
  if (debugging)
    cout << "Parser: entering relop" << endl;

  if (scan->have(symbol::greater_than_sym))
    scan->get_token();
  else if (scan->have(symbol::less_than_sym))
    scan->get_token();
  else if (scan->have(symbol::equals_sym))
    scan->get_token();
  else if (scan->have(symbol::not_equals_sym))
    scan->get_token();
  else if (scan->have(symbol::less_or_equal_sym))
    scan->get_token();
  else 
    scan->must_be(symbol::greater_or_equal_sym);

  if (debugging)
    cout << "Parser: exiting relop" << endl;
}

// <simple_expr> ::= <expr2> { <stringop> <expr2> }*
lille_type parser::simple_expr()
{
  if (debugging)
    cout << "Parser: entering simple_expr" << endl;
  
  lille_type return_type;

  return_type = expr2();
  while (scan->have(symbol::ampersand_sym))
  {
    stringop();
    expr2();
  }

  if (debugging)
    cout << "Parser: exiting simple_expr" << endl;

  return return_type;
}

// <stringop> ::= &
void parser::stringop()
{
  if (debugging)
    cout << "Parser: entering stringop" << endl;

  scan->must_be(symbol::ampersand_sym);

  if (debugging)
    cout << "Parser: exiting stringop" << endl;
}

// <expr2> ::= <term> { { <addop> | or } <term> }*
lille_type parser::expr2()
{
  if (debugging)
    cout << "Parser: entering expr2" << endl;

  lille_type return_type;
  
  return_type = term();
  while (scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym) or scan->have(symbol::or_sym))
  {
    if (scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym))
      addop();
    else 
      scan->must_be(symbol::or_sym);
    term();
  }

  if (debugging)
    cout << "Parser: exiting expr2" << endl;

  return return_type;
}

// <addop> ::= + | –
void parser::addop()
{
  if (debugging)
    cout << "Parser: entering addop" << endl;
  
  if (scan->have(symbol::plus_sym))
    scan->get_token();
  else 
    scan->must_be(symbol::minus_sym);

  if (debugging)
    cout << "Parser: exiting addop" << endl;
}

// <term> ::= <factor> { { <multop> | and } <factor> }*
lille_type parser::term()
{
  if (debugging)
    cout << "Parser: entering term" << endl;

  lille_type return_type;

  return_type = factor();
  while (scan->have(symbol::asterisk_sym) or scan->have(symbol::slash_sym) or scan->have(symbol::and_sym))
  {
    if (scan->have(symbol::asterisk_sym) or scan->have(symbol::slash_sym))
      multop();
    else 
      scan->must_be(symbol::and_sym);
    factor();
  }

  if (debugging)
    cout << "Parser: exiting term" << endl;

  return return_type;
}

// <multop> ::= * | /
void parser::multop()
{
  if (debugging)
    cout << "Parser: entering multop" << endl;

  if (scan->have(symbol::asterisk_sym))
    scan->get_token();
  else 
    scan->must_be(symbol::slash_sym);

  if (debugging)
    cout << "Parser: exiting multop" << endl;
}

//<factor> ::= <primary> [ ** <primary> ]
//            | [ <addop> ] <primary>
lille_type parser::factor()
{
  if (debugging)
    cout << "Parser: entering factor" << endl;
  
  lille_type return_type;

  if (scan->have(symbol::plus_sym) or scan->have(symbol::minus_sym))
    addop();
  return_type = primary();
  if (scan->have(symbol::power_sym))
  {
    scan->get_token();
    primary();
  }

  if (debugging)
    cout << "Parser: exiting factor" << endl;

  return return_type;
}

// <primary> ::= not <expr>
//             | odd <expr>
//             | ( <simple_expr> )
//             | <ident> [ ( <expr>{ , <expr> }* ) ]
//             | <number>
//             | <string>
//             | <bool>
lille_type parser::primary()
{
  if (debugging)
    cout << "Parser: entering primary" << endl;
  
  lille_type return_type;

  if (scan->have(symbol::not_sym))
  {
    scan->get_token();
    expr();
    return_type = lille_type(lille_type::type_boolean);
  }
  else if (scan->have(symbol::odd_sym))
  {
    scan->get_token();
    expr();
    return_type = lille_type(lille_type::type_boolean);
  }
  else if (scan->have(symbol::left_paren_sym))
  {
    scan->get_token();
    simple_expr();
    scan->must_be(symbol::right_paren_sym);
  }
  else if (scan->have(symbol::identifier))
  {
    scan->get_token();
    if (scan->have(symbol::left_paren_sym))
    {
      scan->get_token();
      expr();
      while (scan->have(symbol::comma_sym))
      {
        scan->get_token();
        expr();
      }
      scan->must_be(symbol::right_paren_sym);
    }
  }
  else if (scan->have(symbol::integer) or scan->have(symbol::real_num))
    number();
  else if (scan->have(symbol::strng))
    string();
  else if (scan->have(symbol::true_sym) or scan->have(symbol::false_sym))
    boolean();
  else
    error->flag(scan->this_token(), 128); // factor expected

  if (debugging)
    cout << "Parser: exiting primary" << endl;

  return return_type;
}

// <string> ::= " { <character> }+ "
lille_type parser::string()
{
  if (debugging)
    cout << "Parser: entering string" << endl;

  lille_type return_type;

  scan->must_be(symbol::strng);
  return_type = lille_type(lille_type::type_string);

  if (debugging)
    cout << "Parser: exiting string" << endl;

  return return_type;
}

// <ident> ::= letter { [ _ ] <ident2> }*
lille_type parser::ident()
{
  if (debugging)
    cout << "Parser: entering ident" << endl;
  
  lille_type return_type;

  scan->must_be(symbol::identifier);
//  return_type = lille_type(lille_type::type_ordered);

  if (debugging)
    cout << "Parser: exiting ident" << endl;

  return return_type;
}

// <number> ::= <digit_seq> [. <digit_seq> ] [ <exp> <addop> <digit_seq> ]
lille_type parser::number()
{
  if (debugging)
    cout << "Parser: entering number" << endl;
  
  lille_type return_type;
  
  if (scan->have(symbol::integer))
  {
    scan->get_token();
    return_type = lille_type(lille_type::type_integer);
  }
  else 
  {
    scan->must_be(symbol::real_num);
    return_type = lille_type(lille_type::type_real);
  }

  if (debugging)
    cout << "Parser: exiting number" << endl;
  
  return return_type; 
}

// Called to start parsing the program
lille_type parser::program()
{
  if (debugging)
    cout << "Parser: entering program" << endl;
 
  int return_count = 0; // the number of returns found in the program
      
  lille_type return_type;
 
  token* predefined_func;
  token* argument;
  symbol* predefined_sym;
  id_table_entry* func_id;
  id_table_entry* param_id;

  // adding predefined functions to the id table
  predefined_sym = new symbol(symbol::identifier);
  predefined_func = new token(predefined_sym, 0, 0);
  predefined_func->set_identifier_value("INT2REAL");
  func_id = id_tab->enter_id(predefined_func, lille_type::type_func, lille_kind::unknown, 0, 0, lille_type::type_integer);
  
  argument = new token(predefined_sym, 0, 0);
  argument->set_identifier_value("__int2real_arg__");
  param_id = new id_table_entry(argument, lille_type::type_real, lille_kind::value_param, 0, 0, lille_type::type_unknown);
  func_id->add_param(param_id);

  predefined_sym = new symbol(symbol::identifier);
  predefined_func = new token(predefined_sym, 0, 0);
  predefined_func->set_identifier_value("REAL2INT");
  func_id = id_tab->enter_id(predefined_func, lille_type::type_func, lille_kind::unknown, 0, 0, lille_type::type_real);
  
  argument = new token(predefined_sym, 0, 0);
  argument->set_identifier_value("__real2int_arg__");
  param_id = new id_table_entry(argument, lille_type::type_integer, lille_kind::value_param, 0, 0, lille_type::type_unknown);
  func_id->add_param(param_id);
  
  predefined_sym = new symbol(symbol::identifier);
  predefined_func = new token(predefined_sym, 0, 0);
  predefined_func->set_identifier_value("INT2STRING");
  func_id = id_tab->enter_id(predefined_func, lille_type::type_func, lille_kind::unknown, 0, 0, lille_type::type_string);
  
  argument = new token(predefined_sym, 0, 0);
  argument->set_identifier_value("__int2string_arg__");
  param_id = new id_table_entry(argument, lille_type::type_integer, lille_kind::value_param, 0, 0, lille_type::type_unknown);
  func_id->add_param(param_id);
  
  predefined_sym = new symbol(symbol::identifier);
  predefined_func = new token(predefined_sym, 0, 0);
  predefined_func->set_identifier_value("REAL2STRING");
  func_id = id_tab->enter_id(predefined_func, lille_type::type_func, lille_kind::unknown, 0, 0, lille_type::type_string);
  
  argument = new token(predefined_sym, 0, 0);
  argument->set_identifier_value("__real2string_arg__");
  param_id = new id_table_entry(argument, lille_type::type_real, lille_kind::value_param, 0, 0, lille_type::type_unknown);
  func_id->add_param(param_id);

  scan->get_token();
  prog();
  
  scan->must_be(symbol::end_of_program);
  return_type = lille_type(lille_type::type_boolean);

  if (debugging)
    cout << "Parser: exiting program" << endl;

  return return_type;
}
