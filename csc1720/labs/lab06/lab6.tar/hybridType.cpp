/* Name:
   Date:
   Class:
   Location:

   Implementation file for the derived class autoType:  
   Includes set, get, and simple mutator methods.
*/

#include"hybridType.h"
#include<iomanip>

void hybridType::setChargeLevel(double chargeLevel_in)
{
   if (chargeLevel_in > 0.0 && chargeLevel <= 100.0)
      chargeLevel = chargeLevel_in;
   else
      cerr << "Charge level must be > 0% and <= 100%" << endl;
}

double hybridType::getChargeLevel(void)const
{
   return chargeLevel;
}

void hybridType::setChargeEfficiency(double chargeEff_in)
{
   if (chargeEff_in > 1.0)
      chargeEff = chargeEff_in;
   else
      cerr << "Charge efficiency must be > 1.0" << endl;
}

double hybridType::getChargeEfficiency()const
{
   return chargeEff;
}
